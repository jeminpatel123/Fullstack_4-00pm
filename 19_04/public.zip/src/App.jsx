import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
      <h1>Jemin</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates laboriosam nemo qui iste dignissimos cum deserunt similique? Expedita aliquam porro laborum fugit tempora, debitis et quam nam magni soluta! Nesciunt incidunt non odio ex labore tempora nihil perspiciatis assumenda quisquam! Repudiandae perspiciatis asperiores a ipsam ut quam incidunt magnam, cum dicta. Necessitatibus quos, deserunt ut, adipisci voluptas a reprehenderit illum nobis soluta odit reiciendis temporibus sint quia voluptatibus quisquam nam perspiciatis harum laborum ipsum, unde quod cum expedita? Incidunt, magni sunt neque quae tenetur est! Aliquid deleniti mollitia ab illo quam quas, ut cum rem voluptatem quos magni earum exercitationem!
      </p>
    </div>
  )
}

export default App
